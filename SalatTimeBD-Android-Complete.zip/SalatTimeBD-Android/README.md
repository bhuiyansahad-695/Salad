# Salat Time BD — Native Android (Kotlin + Jetpack Compose)

বাংলাদেশের জন্য নামাজের ওয়াক্তের অ্যাপ: ৬৪ জেলা বা জিপিএস, AlAdhan API থেকে সময়, ফিকহভিত্তিক ওয়াক্ত শেষের হিসাব,
প্রতি ওয়াক্তে আলাদা অ্যালার্ম (অগ্রিম সতর্কতা, নিজের আজান অডিও), অফলাইন ক্যাশ।

## GitHub Actions দিয়ে APK বানানো
1. GitHub-এ নতুন repository খুলুন (Private/Public যেটা ইচ্ছা)।
2. এই ZIP Extract করুন। `SalatTimeBD-Android` ফোল্ডারের **ভেতরের সব ফাইল** (`.github`, `app`, `gradle`, `build.gradle.kts` ইত্যাদি) repository-র **root**-এ আপলোড করুন।
   ফোল্ডারটাকে নিজে একটা সাবফোল্ডার বানিয়ে আপলোড করবেন না, নইলে `.github/workflows` কাজ করবে না।
   `.github` লুকানো ফোল্ডার, তাই ব্রাউজারে ড্র্যাগ-ড্রপের বদলে Git বা GitHub Desktop ব্যবহার করা নিরাপদ:
   ```
   cd SalatTimeBD-Android
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<আপনার-ইউজারনেম>/<repo>.git
   git push -u origin main
   ```
3. repository-র **Actions** ট্যাবে যান → **Build SalatTimeBD APK** → (push করলে নিজে থেকেই চলে; না চললে **Run workflow**)।
4. সবুজ টিক এলে রানটি খুলুন → নিচে **Artifacts** থেকে `SalatTimeBD-debug-apk` ডাউনলোড করুন → ZIP খুলে `app-debug.apk` ফোনে ইনস্টল করুন
   (ফোনে "Install unknown apps" অনুমতি লাগবে)।
5. রান লাল হলে ব্যর্থ ধাপটি খুলে error লগ কপি করে পাঠান।

## Android Studio-তে চালানো
Android Studio (Ladybug বা নতুন) → Open → এই ফোল্ডার সিলেক্ট → Gradle Sync → Run।
এই প্রজেক্টে Gradle Wrapper (`gradlew`) নেই; Android Studio নিজের Gradle ব্যবহারের প্রস্তাব দেবে (Gradle 8.9, JDK 17 নির্বাচন করুন)।

## প্রযুক্তি
Kotlin 2.0.21 • AGP 8.7.3 • Gradle 8.9 • Java 17 • Compose BOM 2024.10.01 • Retrofit • Room (KSP) • DataStore • WorkManager • Play Services Location

## সীমাবদ্ধতা
- নিজের আজান অডিও বর্তমানে Receiver থেকে MediaPlayer-এ বাজে। অনেক লম্বা অডিও নির্ভরযোগ্যভাবে শেষ পর্যন্ত বাজাতে ভবিষ্যতে Foreground Service লাগবে।
- হিজরি তারিখ সরাসরি AlAdhan থেকে আসে; বাংলাদেশের চাঁদ দেখার সঙ্গে ১ দিন পর্যন্ত পার্থক্য হতে পারে।

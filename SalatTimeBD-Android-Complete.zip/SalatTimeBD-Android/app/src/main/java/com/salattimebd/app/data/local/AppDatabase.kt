package com.salattimebd.app.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

/** একটি তারিখ + অবস্থান + পদ্ধতির জন্য API উত্তরের JSON ক্যাশ। অফলাইনেও সময় দেখানোর জন্য। */
@Entity(tableName = "prayer_cache")
data class CachedPrayerEntity(
    @PrimaryKey val cacheKey: String,
    val responseJson: String,
    val fetchedAt: Long
)

@Dao
interface PrayerCacheDao {
    @Query("SELECT * FROM prayer_cache WHERE cacheKey = :key LIMIT 1")
    suspend fun get(key: String): CachedPrayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CachedPrayerEntity)

    @Query("DELETE FROM prayer_cache WHERE fetchedAt < :before")
    suspend fun deleteOlderThan(before: Long)
}

@Database(entities = [CachedPrayerEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun prayerCacheDao(): PrayerCacheDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "salat_time.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

package com.salattimebd.app.data.repository

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.salattimebd.app.data.api.AlAdhanApiService
import com.salattimebd.app.data.local.AppDatabase
import com.salattimebd.app.data.local.CachedPrayerEntity
import com.salattimebd.app.data.model.AlAdhanApiResponse
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.util.BengaliUtils
import com.salattimebd.app.util.FiqhEndTimeCalculator
import com.salattimebd.app.util.PrayerTimeUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class PrayerRepository(context: Context) {

    private val appContext = context.applicationContext
    private val api: AlAdhanApiService by lazy { AlAdhanApiService.create() }
    private val dao by lazy { AppDatabase.get(appContext).prayerCacheDao() }
    private val prefs = UserPreferencesRepository(appContext)
    private val gson = Gson()

    /**
     * @param dayOffset ০ = আজ, ১ = আগামীকাল (অ্যালার্ম আগেভাগে সেট করার জন্য)
     * @param schoolId AlAdhan school: ১ = হানাফী, ০ = অন্যান্য
     */
    suspend fun getPrayerTimes(
        latitude: Double,
        longitude: Double,
        locationName: String,
        methodId: Int,
        schoolId: Int,
        forceRefresh: Boolean = false,
        dayOffset: Int = 0
    ): Resource<DailyPrayerData> = withContext(Dispatchers.IO) {
        val date = LocalDate.now().plusDays(dayOffset.toLong())
        val key = cacheKey(date, latitude, longitude, methodId, schoolId)
        val cached: CachedPrayerEntity? = try {
            dao.get(key)
        } catch (e: Exception) {
            Log.w(TAG, "Cache read failed", e)
            null
        }

        if (!forceRefresh && cached != null) {
            val fromCache = parseCached(cached, date, locationName, schoolId, offline = false)
            if (fromCache != null) return@withContext Resource.Success(fromCache)
        }

        try {
            val response = api.getTimings(
                date = date.format(API_DATE_FORMAT),
                latitude = latitude,
                longitude = longitude,
                method = methodId,
                school = schoolId
            )
            val now = System.currentTimeMillis()
            val daily = buildDaily(response, date, locationName, schoolId, now, offline = false)

            try {
                dao.upsert(CachedPrayerEntity(key, gson.toJson(response), now))
                dao.deleteOlderThan(now - CACHE_RETENTION_MS)
            } catch (e: Exception) {
                Log.w(TAG, "Cache write failed", e)
            }
            if (dayOffset == 0) prefs.updateSyncStatus(now, "সফল")
            Resource.Success(daily)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Fetch failed", e)
            val now = System.currentTimeMillis()
            if (dayOffset == 0) {
                prefs.updateSyncStatus(now, "ব্যর্থ (${e.javaClass.simpleName})")
            }
            val fallback = cached?.let { parseCached(it, date, locationName, schoolId, offline = true) }
            if (fallback != null) {
                Resource.Success(fallback)
            } else {
                Resource.Error(
                    "ইন্টারনেট সংযোগ নেই বা সার্ভারে পৌঁছানো যায়নি। সংযোগ দেখে আবার চেষ্টা করুন।",
                    e
                )
            }
        }
    }

    private fun parseCached(
        entity: CachedPrayerEntity,
        date: LocalDate,
        locationName: String,
        schoolId: Int,
        offline: Boolean
    ): DailyPrayerData? {
        return try {
            val response = gson.fromJson(entity.responseJson, AlAdhanApiResponse::class.java)
                ?: return null
            buildDaily(response, date, locationName, schoolId, entity.fetchedAt, offline)
        } catch (e: Exception) {
            Log.w(TAG, "Cached JSON unusable", e)
            null
        }
    }

    private fun buildDaily(
        response: AlAdhanApiResponse,
        date: LocalDate,
        locationName: String,
        schoolId: Int,
        fetchedAt: Long,
        offline: Boolean
    ): DailyPrayerData {
        val data = response.data ?: throw IOException("সার্ভার থেকে খালি উত্তর এসেছে")
        val t = data.timings ?: throw IOException("সার্ভারের উত্তরে ওয়াক্তের তথ্য নেই")
        val required = listOf(t.fajr, t.sunrise, t.dhuhr, t.asr, t.maghrib, t.isha)
        if (required.any { it.isNullOrBlank() }) {
            throw IOException("সার্ভারের উত্তরে কিছু ওয়াক্তের সময় অনুপস্থিত")
        }

        val timings = FiqhEndTimeCalculator.calculatePrayerBoundaries(
            fajr = t.fajr.orEmpty(),
            sunrise = t.sunrise.orEmpty(),
            dhuhr = t.dhuhr.orEmpty(),
            asr = t.asr.orEmpty(),
            maghrib = t.maghrib.orEmpty(),
            isha = t.isha.orEmpty(),
            asrSchool = if (schoolId == 1) "Hanafi" else "Standard"
        )

        val hijri = data.date?.hijri
        val day = hijri?.day?.trim()
        val monthNo = hijri?.month?.number
        val year = hijri?.year?.trim()
        val hijriText = if (!day.isNullOrEmpty() && monthNo != null && !year.isNullOrEmpty()) {
            "$day ${BengaliUtils.hijriMonthName(monthNo)} $year হিজরি"
        } else {
            ""
        }

        return DailyPrayerData(
            dateIso = date.toString(),
            locationName = locationName,
            hijriDateText = hijriText,
            timezoneId = PrayerTimeUtils.safeZone(data.meta?.timezone).id,
            timings = timings,
            isOfflineFallback = offline,
            fetchedAt = fetchedAt
        )
    }

    private fun cacheKey(date: LocalDate, lat: Double, lng: Double, methodId: Int, schoolId: Int): String {
        val latStr = String.format(Locale.US, "%.2f", lat)
        val lngStr = String.format(Locale.US, "%.2f", lng)
        return "${date}_${latStr}_${lngStr}_m${methodId}_s${schoolId}"
    }

    companion object {
        private const val TAG = "PrayerRepository"
        private const val CACHE_RETENTION_MS = 7L * 24 * 60 * 60 * 1000
        private val API_DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.US)
    }
}

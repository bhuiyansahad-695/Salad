package com.salattimebd.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** ফোন রিস্টার্ট, সময়/টাইমজোন পরিবর্তন বা অ্যাপ আপডেটের পর অ্যালার্ম আবার সেট করে। */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> PrayerRescheduleWorker.enqueueNow(context)
        }
    }
}

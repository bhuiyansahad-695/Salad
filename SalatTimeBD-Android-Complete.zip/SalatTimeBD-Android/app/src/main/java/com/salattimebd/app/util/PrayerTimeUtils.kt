package com.salattimebd.app.util

import java.time.LocalDate
import java.time.ZoneId

object PrayerTimeUtils {

    const val DAY_MS = 24L * 60 * 60 * 1000
    private const val DEFAULT_ZONE = "Asia/Dhaka"

    data class WaqtStatus(
        val currentName: String?,
        val currentEndMillis: Long?,
        val nextName: String,
        val nextStartMillis: Long
    )

    fun safeZone(zoneId: String?): ZoneId {
        return try {
            if (zoneId.isNullOrBlank()) ZoneId.of(DEFAULT_ZONE) else ZoneId.of(zoneId)
        } catch (e: Exception) {
            ZoneId.of(DEFAULT_ZONE)
        }
    }

    /** "HH:mm" সময়কে নির্দিষ্ট তারিখ ও টাইমজোনে epoch millis-এ রূপান্তর করে। */
    fun epochOf(date: LocalDate, time24: String, zone: ZoneId): Long {
        val parts = time24.trim().split(":")
        val h = (parts.getOrNull(0)?.toIntOrNull() ?: 0).coerceIn(0, 23)
        val m = (parts.getOrNull(1)?.toIntOrNull() ?: 0).coerceIn(0, 59)
        return date.atTime(h, m).atZone(zone).toInstant().toEpochMilli()
    }

    /** এখন কোন ওয়াক্ত চলছে এবং পরবর্তী ফরজ ওয়াক্ত কখন। */
    fun computeStatus(
        timings: List<PrayerTiming>,
        dateIso: String,
        zoneId: String?,
        nowMillis: Long
    ): WaqtStatus? {
        if (timings.isEmpty()) return null
        val zone = safeZone(zoneId)
        val date = try {
            LocalDate.parse(dateIso)
        } catch (e: Exception) {
            return null
        }

        val windows = timings.map { t ->
            val start = epochOf(date, t.startTime, zone)
            var end = epochOf(date, t.endTime, zone)
            if (end <= start) end += DAY_MS // মধ্যরাত পেরিয়ে যাওয়া শেষ সময় (এশা)
            Triple(t, start, end)
        }

        val current = windows.firstOrNull { nowMillis >= it.second && nowMillis < it.third }
        val nextToday = windows
            .filter { it.first.isObligatory && it.second > nowMillis }
            .minByOrNull { it.second }

        val nextName: String
        val nextStart: Long
        if (nextToday != null) {
            nextName = nextToday.first.nameBn
            nextStart = nextToday.second
        } else {
            val firstFard = windows.firstOrNull { it.first.isObligatory } ?: return null
            nextName = firstFard.first.nameBn
            nextStart = firstFard.second + DAY_MS // আগামীকালের ফজর (আনুমানিক)
        }

        return WaqtStatus(
            currentName = current?.first?.nameBn,
            currentEndMillis = current?.third,
            nextName = nextName,
            nextStartMillis = nextStart
        )
    }
}

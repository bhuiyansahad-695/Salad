package com.salattimebd.app.data.model

import com.google.gson.annotations.SerializedName

/** AlAdhan `/v1/timings/{date}` এর উত্তর। সব ফিল্ড nullable, যাতে সার্ভার কিছু বাদ দিলেও Gson ক্র্যাশ না করে। */
data class AlAdhanApiResponse(
    @SerializedName("code") val code: Int? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("data") val data: AlAdhanData? = null
)

data class AlAdhanData(
    @SerializedName("timings") val timings: AlAdhanTimings? = null,
    @SerializedName("date") val date: AlAdhanDate? = null,
    @SerializedName("meta") val meta: AlAdhanMeta? = null
)

data class AlAdhanTimings(
    @SerializedName("Fajr") val fajr: String? = null,
    @SerializedName("Sunrise") val sunrise: String? = null,
    @SerializedName("Dhuhr") val dhuhr: String? = null,
    @SerializedName("Asr") val asr: String? = null,
    @SerializedName("Sunset") val sunset: String? = null,
    @SerializedName("Maghrib") val maghrib: String? = null,
    @SerializedName("Isha") val isha: String? = null,
    @SerializedName("Imsak") val imsak: String? = null,
    @SerializedName("Midnight") val midnight: String? = null
)

data class AlAdhanDate(
    @SerializedName("readable") val readable: String? = null,
    @SerializedName("hijri") val hijri: AlAdhanHijri? = null
)

data class AlAdhanHijri(
    @SerializedName("day") val day: String? = null,
    @SerializedName("month") val month: AlAdhanHijriMonth? = null,
    @SerializedName("year") val year: String? = null
)

data class AlAdhanHijriMonth(
    @SerializedName("number") val number: Int? = null,
    @SerializedName("en") val en: String? = null
)

data class AlAdhanMeta(
    @SerializedName("timezone") val timezone: String? = null
)

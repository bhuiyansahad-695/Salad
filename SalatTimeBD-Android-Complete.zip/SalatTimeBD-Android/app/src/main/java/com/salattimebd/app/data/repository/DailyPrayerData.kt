package com.salattimebd.app.data.repository

import com.salattimebd.app.util.PrayerTiming

data class DailyPrayerData(
    /** yyyy-MM-dd */
    val dateIso: String,
    val locationName: String,
    /** ইংরেজি অঙ্কে, যেমন "9 জমাদিউল আউয়াল 1448 হিজরি"; UI-তে সংখ্যা রূপান্তর হয়। খালি হতে পারে। */
    val hijriDateText: String,
    /** API-র meta থেকে পাওয়া টাইমজোন, যেমন "Asia/Dhaka" */
    val timezoneId: String,
    /** ফজর, সূর্যোদয়, যোহর, আসর, মাগরিব, এশা (সূর্যোদয়ের isObligatory = false) */
    val timings: List<PrayerTiming>,
    /** ইন্টারনেট না থাকায় পুরনো ক্যাশ দেখানো হচ্ছে কি না */
    val isOfflineFallback: Boolean = false,
    val fetchedAt: Long = 0L
)

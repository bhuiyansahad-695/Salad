package com.salattimebd.app.data.preferences

/**
 * প্রতিটি ওয়াক্তের অ্যালার্ম কনফিগারেশন।
 * soundMode: "default" (সিস্টেম নোটিফিকেশন সাউন্ড) | "vibrate" (শুধু ভাইব্রেশন) | "custom_adhan" (নিজের অডিও)
 */
data class PrayerAlarmConfig(
    val enabled: Boolean = true,
    val minutesBefore: Int = 0,
    val soundMode: String = "default",
    val customAudioUri: String? = null
)

data class UserSettings(
    val useGps: Boolean = false,
    val selectedDistrict: String = "ঢাকা",
    val latitude: Double = 23.8103,
    val longitude: Double = 90.4125,
    /** AlAdhan calculation method। ১ = University of Islamic Sciences, Karachi (বাংলাদেশে প্রচলিত) */
    val calculationMethodId: Int = 1,
    /** AlAdhan school। ১ = হানাফী, ০ = শাফেয়ী/মালেকী/হাম্বলী */
    val asrSchool: Int = 1,
    val useBengaliNumerals: Boolean = true,
    val fajrAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val dhuhrAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val asrAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val maghribAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val ishaAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val lastSyncTimestamp: Long = 0L,
    val lastSyncStatus: String = ""
) {
    fun alarmFor(prayerId: String): PrayerAlarmConfig = when (prayerId) {
        "fajr" -> fajrAlarm
        "dhuhr" -> dhuhrAlarm
        "asr" -> asrAlarm
        "maghrib" -> maghribAlarm
        else -> ishaAlarm
    }

    fun alarmConfigs(): Map<String, PrayerAlarmConfig> = mapOf(
        "fajr" to fajrAlarm,
        "dhuhr" to dhuhrAlarm,
        "asr" to asrAlarm,
        "maghrib" to maghribAlarm,
        "isha" to ishaAlarm
    )
}

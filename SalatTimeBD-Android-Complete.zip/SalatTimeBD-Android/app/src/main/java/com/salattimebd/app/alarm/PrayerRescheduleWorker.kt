package com.salattimebd.app.alarm

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.data.repository.PrayerRepository
import com.salattimebd.app.data.repository.Resource
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * আজ ও আগামীকালের অ্যালার্ম সেট করে। চালু হয়:
 * - প্রতি ৬ ঘণ্টায় (ব্যাকগ্রাউন্ডে)
 * - ফোন রিস্টার্ট / সময় বা টাইমজোন পরিবর্তন / অ্যাপ আপডেটের পর (BootReceiver)
 * - প্রতিটি অ্যালার্ম বাজার পর (পরের দিনের অ্যালার্ম নিশ্চিত করতে)
 * - অ্যাপ খুললে ও অ্যালার্ম সেটিংস বদলালে
 */
class PrayerRescheduleWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val settings = UserPreferencesRepository(applicationContext).userSettingsFlow.first()
            val repo = PrayerRepository(applicationContext)
            val scheduler = PrayerAlarmScheduler(applicationContext)
            val configs = settings.alarmConfigs()

            var todayScheduled = false
            for (offset in 0..1) {
                val result = repo.getPrayerTimes(
                    latitude = settings.latitude,
                    longitude = settings.longitude,
                    locationName = settings.selectedDistrict,
                    methodId = settings.calculationMethodId,
                    schoolId = settings.asrSchool,
                    forceRefresh = false,
                    dayOffset = offset
                )
                if (result is Resource.Success) {
                    scheduler.scheduleAllPrayers(result.data.timings, configs, offset, result.data.timezoneId)
                    if (offset == 0) todayScheduled = true
                }
            }
            if (todayScheduled) Result.success() else Result.retry()
        } catch (e: Exception) {
            Log.w(TAG, "Reschedule failed", e)
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "PrayerRescheduleWorker"
        private const val UNIQUE_PERIODIC = "salat_periodic_reschedule"
        private const val UNIQUE_ONE_SHOT = "salat_reschedule_now"

        fun enqueueNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<PrayerRescheduleWorker>().build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniqueWork(UNIQUE_ONE_SHOT, ExistingWorkPolicy.REPLACE, request)
        }

        fun ensurePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<PrayerRescheduleWorker>(6, TimeUnit.HOURS).build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniquePeriodicWork(UNIQUE_PERIODIC, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}

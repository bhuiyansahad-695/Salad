package com.salattimebd.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.salattimebd.app.data.BangladeshDistricts
import com.salattimebd.app.data.preferences.UserSettings

/** AlAdhan calculation method id -> বাংলা নাম */
private val CALCULATION_METHODS = listOf(
    1 to "করাচি — University of Islamic Sciences (বাংলাদেশে প্রচলিত)",
    2 to "ISNA — উত্তর আমেরিকা",
    3 to "মুসলিম ওয়ার্ল্ড লীগ",
    4 to "উম্মুল কুরা — মক্কা",
    5 to "মিশরীয় জেনারেল অথরিটি অব সার্ভে",
    15 to "Moonsighting Committee Worldwide"
)

private val ASR_SCHOOLS = listOf(
    1 to "হানাফী (ছায়া দ্বিগুণ হলে আসর শুরু)",
    0 to "শাফেয়ী / মালেকী / হাম্বলী (ছায়া একগুণ হলে আসর শুরু)"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    userSettings: UserSettings,
    onBack: () -> Unit,
    onUpdateGps: (Boolean) -> Unit,
    onSelectDistrict: (String, Double, Double) -> Unit,
    onUpdateCalculationMethod: (Int) -> Unit,
    onUpdateAsrSchool: (Int) -> Unit,
    onUpdateNumerals: (Boolean) -> Unit
) {
    var showDistrictDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সেটিংস", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("অবস্থান") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("জিপিএস থেকে অবস্থান নিন", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "চালু করলে অ্যাপ ব্যবহারের সময় আপনার বর্তমান অবস্থান দিয়ে ওয়াক্ত হিসাব হবে।",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = userSettings.useGps, onCheckedChange = onUpdateGps)
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                Text("বর্তমান অবস্থান: ${userSettings.selectedDistrict}", style = MaterialTheme.typography.bodyLarge)
                OutlinedButton(
                    onClick = { showDistrictDialog = true },
                    modifier = Modifier.padding(top = 8.dp)
                ) { Text("জেলা বাছাই করুন") }
            }

            SectionCard("গণনা পদ্ধতি") {
                CALCULATION_METHODS.forEach { (id, label) ->
                    RadioRow(
                        label = label,
                        selected = userSettings.calculationMethodId == id,
                        onClick = { onUpdateCalculationMethod(id) }
                    )
                }
            }

            SectionCard("আসরের মাযহাব") {
                ASR_SCHOOLS.forEach { (id, label) ->
                    RadioRow(
                        label = label,
                        selected = userSettings.asrSchool == id,
                        onClick = { onUpdateAsrSchool(id) }
                    )
                }
            }

            SectionCard("প্রদর্শন") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("বাংলা অঙ্ক ব্যবহার করুন", modifier = Modifier.weight(1f))
                    Switch(checked = userSettings.useBengaliNumerals, onCheckedChange = onUpdateNumerals)
                }
            }
        }
    }

    if (showDistrictDialog) {
        AlertDialog(
            onDismissRequest = { showDistrictDialog = false },
            title = { Text("জেলা বাছাই করুন") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                    items(BangladeshDistricts.all, key = { it.nameBn }) { district ->
                        Text(
                            text = district.nameBn,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = if (district.nameBn == userSettings.selectedDistrict && !userSettings.useGps) {
                                FontWeight.Bold
                            } else {
                                FontWeight.Normal
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectDistrict(district.nameBn, district.latitude, district.longitude)
                                    showDistrictDialog = false
                                }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDistrictDialog = false }) { Text("বন্ধ করুন") }
            }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Column(
                modifier = Modifier.padding(top = 8.dp),
                content = content
            )
        }
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

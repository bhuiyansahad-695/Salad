package com.salattimebd.app.ui.screens

import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.salattimebd.app.alarm.PrayerAlarmScheduler
import com.salattimebd.app.util.BengaliUtils
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsScreen(
    lastSyncTimestamp: Long,
    lastSyncStatus: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val notificationsOk = remember { NotificationManagerCompat.from(context).areNotificationsEnabled() }
    val exactAlarmOk = remember { PrayerAlarmScheduler(context).canScheduleExactAlarms() }
    val batteryUnrestricted = remember {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    val syncTimeText = if (lastSyncTimestamp <= 0L) {
        "এখনো সিঙ্ক হয়নি"
    } else {
        val formatted = Instant.ofEpochMilli(lastSyncTimestamp)
            .atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy, hh:mm a", Locale.US))
        BengaliUtils.toBengaliDigits(formatted)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ডায়াগনস্টিকস", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("ওয়াক্তের তথ্য সিঙ্ক", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    StatusLine("সর্বশেষ সিঙ্ক", syncTimeText)
                    StatusLine("অবস্থা", lastSyncStatus.ifEmpty { "—" })
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("অ্যালার্ম প্রস্তুতি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    StatusLine("নোটিফিকেশন", if (notificationsOk) "✓ চালু" else "✗ বন্ধ — ফোনের সেটিংস থেকে চালু করুন")
                    StatusLine("সঠিক সময়ের অ্যালার্ম", if (exactAlarmOk) "✓ অনুমোদিত" else "✗ অনুমতি নেই — সময়ে কিছু দেরি হতে পারে")
                    StatusLine("ব্যাটারি সীমাবদ্ধতা", if (batteryUnrestricted) "✓ মুক্ত" else "সীমাবদ্ধ — কিছু ফোনে অ্যালার্ম দেরিতে বাজতে পারে")
                    if (!batteryUnrestricted) {
                        OutlinedButton(
                            onClick = {
                                context.startActivity(
                                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        ) { Text("ব্যাটারি সেটিংস খুলুন") }
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "হিজরি তারিখ ও ওয়াক্তের সময় অনলাইন সেবা (AlAdhan) থেকে হিসাব করা। চাঁদ দেখার ভিত্তিতে বাংলাদেশে হিজরি তারিখ ১ দিন পর্যন্ত ভিন্ন হতে পারে; সময়ের সামান্য পার্থক্য হলে স্থানীয় মসজিদের সময়সূচি অনুসরণ করুন।",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1.4f))
    }
}

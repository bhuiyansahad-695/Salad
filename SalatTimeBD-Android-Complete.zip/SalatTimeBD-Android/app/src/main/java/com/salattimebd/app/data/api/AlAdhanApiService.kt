package com.salattimebd.app.data.api

import com.salattimebd.app.data.model.AlAdhanApiResponse
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface AlAdhanApiService {
    @GET("v1/timings/{date}")
    suspend fun getTimings(
        @Path("date") date: String,
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("method") method: Int = 1,
        @Query("school") school: Int = 1
    ): AlAdhanApiResponse

    companion object {
        fun create(): AlAdhanApiService {
            return Retrofit.Builder()
                .baseUrl("https://api.aladhan.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(AlAdhanApiService::class.java)
        }
    }
}
package com.salattimebd.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.salattimebd.app.data.preferences.PrayerAlarmConfig
import com.salattimebd.app.util.PrayerTimeUtils
import com.salattimebd.app.util.PrayerTiming
import java.time.LocalDate

class PrayerAlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    companion object {
        private const val TAG = "PrayerAlarmScheduler"
        const val ACTION_PRAYER_ALARM = "com.salattimebd.app.ACTION_PRAYER_ALARM"
        const val EXTRA_PRAYER_ID = "extra_prayer_id"
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_IS_REMINDER = "extra_is_reminder"
        const val EXTRA_MINUTES_BEFORE = "extra_minutes_before"
        const val EXTRA_SOUND_MODE = "extra_sound_mode"
        const val EXTRA_AUDIO_URI = "extra_audio_uri"
        private const val REQ_BASE_START = 1000
        private const val REQ_BASE_REMINDER = 2000
        /** প্রতিটি দিনের (আজ/আগামীকাল) জন্য আলাদা requestCode স্লট */
        private const val DAY_SLOT = 10
        /** আজ (০) ও আগামীকাল (১) */
        private const val DAYS_AHEAD = 2
        val PRAYER_IDS = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")
    }

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * @param dayOffset ০ = আজকের ওয়াক্ত, ১ = আগামীকালের ওয়াক্ত
     * @param zoneId ওয়াক্তের অবস্থানের টাইমজোন (API-র meta থেকে)
     */
    fun scheduleAllPrayers(
        timings: List<PrayerTiming>,
        configs: Map<String, PrayerAlarmConfig>,
        dayOffset: Int = 0,
        zoneId: String = "Asia/Dhaka"
    ) {
        val now = System.currentTimeMillis()
        val zone = PrayerTimeUtils.safeZone(zoneId)
        val date = LocalDate.now(zone).plusDays(dayOffset.toLong())

        timings.filter { it.isObligatory }.forEach { timing ->
            val prayerId = timing.id
            val config = configs[prayerId] ?: PrayerAlarmConfig()
            val baseId = PRAYER_IDS.indexOf(prayerId).coerceAtLeast(0)

            if (!config.enabled) {
                // বন্ধ করলে আজ ও আগামীকাল দুই দিনের অ্যালার্মই বাতিল
                for (day in 0 until DAYS_AHEAD) {
                    cancelAlarm(startRequestCode(day, baseId))
                    cancelAlarm(reminderRequestCode(day, baseId))
                }
                return@forEach
            }

            val startReqCode = startRequestCode(dayOffset, baseId)
            val reminderReqCode = reminderRequestCode(dayOffset, baseId)

            val prayerEpoch = PrayerTimeUtils.epochOf(date, timing.startTime, zone)
            if (prayerEpoch > now) {
                scheduleExact(prayerEpoch, startReqCode, prayerId, timing.nameBn, false, 0, config.soundMode, config.customAudioUri)
            } else {
                cancelAlarm(startReqCode)
            }

            if (config.minutesBefore > 0) {
                val reminderEpoch = prayerEpoch - (config.minutesBefore * 60 * 1000L)
                if (reminderEpoch > now) {
                    scheduleExact(reminderEpoch, reminderReqCode, prayerId, timing.nameBn, true, config.minutesBefore, config.soundMode, config.customAudioUri)
                } else {
                    cancelAlarm(reminderReqCode)
                }
            } else {
                // আগে অগ্রিম সতর্কতা চালু থাকলে এখন বন্ধ করা হয়েছে — পুরনো অ্যালার্ম মুছে ফেলা
                cancelAlarm(reminderReqCode)
            }
        }
    }

    private fun startRequestCode(dayOffset: Int, baseId: Int) = REQ_BASE_START + dayOffset * DAY_SLOT + baseId

    private fun reminderRequestCode(dayOffset: Int, baseId: Int) = REQ_BASE_REMINDER + dayOffset * DAY_SLOT + baseId

    private fun scheduleExact(
        triggerTime: Long,
        reqCode: Int,
        id: String,
        name: String,
        isRem: Boolean,
        minBefore: Int,
        sound: String,
        uri: String?
    ) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER_ALARM
            putExtra(EXTRA_PRAYER_ID, id)
            putExtra(EXTRA_PRAYER_NAME, name)
            putExtra(EXTRA_IS_REMINDER, isRem)
            putExtra(EXTRA_MINUTES_BEFORE, minBefore)
            putExtra(EXTRA_SOUND_MODE, sound)
            putExtra(EXTRA_AUDIO_URI, uri)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, reqCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } else {
                // অনুমতি না থাকলে কিছুটা অনিশ্চিত সময়ে হলেও অ্যালার্ম বাজবে
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact alarm denied, falling back to inexact", e)
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        }
    }

    private fun cancelAlarm(reqCode: Int) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, reqCode, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}

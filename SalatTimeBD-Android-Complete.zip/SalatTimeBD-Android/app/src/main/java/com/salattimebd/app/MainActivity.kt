package com.salattimebd.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.salattimebd.app.alarm.PrayerAlarmScheduler
import com.salattimebd.app.alarm.PrayerRescheduleWorker
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.data.preferences.UserSettings
import com.salattimebd.app.data.repository.DailyPrayerData
import com.salattimebd.app.data.repository.PrayerRepository
import com.salattimebd.app.data.repository.Resource
import com.salattimebd.app.ui.screens.DiagnosticsScreen
import com.salattimebd.app.ui.screens.HomeScreen
import com.salattimebd.app.ui.screens.SettingsScreen
import com.salattimebd.app.ui.theme.SalatTimeBDTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainActivity : ComponentActivity() {

    private lateinit var prayerRepo: PrayerRepository
    private lateinit var prefsRepo: UserPreferencesRepository
    private lateinit var alarmScheduler: PrayerAlarmScheduler
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var testMediaPlayer: MediaPlayer? = null
    private var activeCustomAudioPrayerId: String? = null

    // Android 13+ নোটিফিকেশন অনুমতি
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(
                this,
                "নোটিফিকেশনের অনুমতি না দিলে নামাজের সতর্কবার্তা দেখা যাবে না",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // জিপিএস অবস্থানের অনুমতি (শুধু অ্যাপ ব্যবহারের সময়)
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) {
            fetchGpsLocation()
        } else {
            Toast.makeText(this, "অবস্থানের অনুমতি দেওয়া হয়নি। জেলা বাছাই করে ব্যবহার করুন।", Toast.LENGTH_LONG).show()
            lifecycleScope.launch {
                val s = prefsRepo.userSettingsFlow.first()
                prefsRepo.updateLocation(false, s.selectedDistrict, s.latitude, s.longitude)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prayerRepo = PrayerRepository(this)
        prefsRepo = UserPreferencesRepository(this)
        alarmScheduler = PrayerAlarmScheduler(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            SalatTimeBDTheme {
                val navController = rememberNavController()
                val userSettings by prefsRepo.userSettingsFlow.collectAsState(initial = UserSettings())
                var prayerState by remember { mutableStateOf<Resource<DailyPrayerData>>(Resource.Loading) }

                // তারিখ বদলালে (মধ্যরাত পার হলে) নতুন দিনের সময় আনার জন্য
                var todayKey by remember { mutableStateOf(LocalDate.now().toString()) }
                LaunchedEffect(Unit) {
                    while (true) {
                        delay(60_000L)
                        val d = LocalDate.now().toString()
                        if (d != todayKey) todayKey = d
                    }
                }

                // Android 12/12L-এ "Alarms & reminders" অনুমতি ম্যানুয়ালি দিতে হয়
                var showExactAlarmDialog by remember {
                    mutableStateOf(
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                            Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2 &&
                            !alarmScheduler.canScheduleExactAlarms()
                    )
                }
                if (showExactAlarmDialog) {
                    AlertDialog(
                        onDismissRequest = { showExactAlarmDialog = false },
                        title = { Text("সঠিক সময়ে অ্যালার্মের অনুমতি") },
                        text = { Text("ওয়াক্ত শুরুর ঠিক সময়ে সতর্ক করতে \"Alarms & reminders\" অনুমতি চালু করুন।") },
                        confirmButton = {
                            TextButton(onClick = {
                                showExactAlarmDialog = false
                                startActivity(
                                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                                )
                            }) { Text("সেটিংস খুলুন") }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExactAlarmDialog = false }) { Text("পরে") }
                        }
                    )
                }

                // Audio Picker Launcher for custom Adhan file
                // OpenDocument ব্যবহার করা হয়েছে যাতে ফাইলের স্থায়ী পড়ার অনুমতি রাখা যায় (রিস্টার্টের পরও আজান বাজে)
                val audioPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    val prayerId = activeCustomAudioPrayerId
                    if (uri != null && prayerId != null) {
                        try {
                            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        } catch (e: SecurityException) {
                            // কিছু provider স্থায়ী অনুমতি দেয় না; তবুও সংরক্ষণ চলবে
                        }
                        lifecycleScope.launch {
                            val oldConfig = userSettings.alarmFor(prayerId)
                            prefsRepo.updateAlarmConfig(
                                prayerId,
                                oldConfig.copy(customAudioUri = uri.toString(), soundMode = "custom_adhan")
                            )
                            Toast.makeText(this@MainActivity, "আজান অডিও সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                // জিপিএস চালু থাকলে অ্যাপ খোলার সময় অবস্থান হালনাগাদ
                LaunchedEffect(userSettings.useGps) {
                    if (userSettings.useGps) fetchGpsLocation()
                }

                LaunchedEffect(
                    userSettings.latitude,
                    userSettings.longitude,
                    userSettings.calculationMethodId,
                    userSettings.asrSchool,
                    todayKey
                ) {
                    prayerState = Resource.Loading
                    val result = prayerRepo.getPrayerTimes(
                        latitude = userSettings.latitude,
                        longitude = userSettings.longitude,
                        locationName = userSettings.selectedDistrict,
                        methodId = userSettings.calculationMethodId,
                        schoolId = userSettings.asrSchool,
                        forceRefresh = false
                    )
                    prayerState = result
                }

                // সময় পাওয়া গেলে বা অ্যালার্ম কনফিগ বদলালে অ্যালার্ম আবার সেট করা
                LaunchedEffect(
                    prayerState,
                    userSettings.fajrAlarm,
                    userSettings.dhuhrAlarm,
                    userSettings.asrAlarm,
                    userSettings.maghribAlarm,
                    userSettings.ishaAlarm
                ) {
                    val state = prayerState
                    if (state is Resource.Success) {
                        alarmScheduler.scheduleAllPrayers(
                            state.data.timings,
                            userSettings.alarmConfigs(),
                            0,
                            state.data.timezoneId
                        )
                        // আগামীকালের অ্যালার্মও আগেভাগে সেট হবে
                        PrayerRescheduleWorker.enqueueNow(applicationContext)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                prayerDataState = prayerState,
                                userSettings = userSettings,
                                onManualRefresh = {
                                    lifecycleScope.launch {
                                        prayerState = Resource.Loading
                                        prayerState = prayerRepo.getPrayerTimes(
                                            latitude = userSettings.latitude,
                                            longitude = userSettings.longitude,
                                            locationName = userSettings.selectedDistrict,
                                            methodId = userSettings.calculationMethodId,
                                            schoolId = userSettings.asrSchool,
                                            forceRefresh = true
                                        )
                                    }
                                },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToDiagnostics = { navController.navigate("diagnostics") },
                                onAlarmToggle = { id, enabled ->
                                    lifecycleScope.launch {
                                        val oldConfig = userSettings.alarmFor(id)
                                        prefsRepo.updateAlarmConfig(id, oldConfig.copy(enabled = enabled))
                                    }
                                },
                                onSaveAlarmConfig = { id, updatedConfig ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateAlarmConfig(id, updatedConfig)
                                    }
                                },
                                onSelectAudio = { prayerId ->
                                    activeCustomAudioPrayerId = prayerId
                                    audioPickerLauncher.launch(arrayOf("audio/*"))
                                },
                                onPreviewAudio = { mode, uriStr ->
                                    previewAudio(mode, uriStr)
                                }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                userSettings = userSettings,
                                onBack = { navController.popBackStack() },
                                onUpdateGps = { useGps ->
                                    if (useGps) {
                                        requestGpsLocation()
                                    } else {
                                        lifecycleScope.launch {
                                            prefsRepo.updateLocation(false, userSettings.selectedDistrict, userSettings.latitude, userSettings.longitude)
                                        }
                                    }
                                },
                                onSelectDistrict = { name, lat, lng ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateLocation(false, name, lat, lng)
                                    }
                                },
                                onUpdateCalculationMethod = { mId ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateCalculationSettings(mId, userSettings.asrSchool)
                                    }
                                },
                                onUpdateAsrSchool = { sId ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateCalculationSettings(userSettings.calculationMethodId, sId)
                                    }
                                },
                                onUpdateNumerals = { useBn ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateBengaliNumerals(useBn)
                                    }
                                }
                            )
                        }
                        composable("diagnostics") {
                            DiagnosticsScreen(
                                lastSyncTimestamp = userSettings.lastSyncTimestamp,
                                lastSyncStatus = userSettings.lastSyncStatus,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestGpsLocation() {
        if (hasLocationPermission()) {
            Toast.makeText(this, "অবস্থান নির্ণয় করা হচ্ছে...", Toast.LENGTH_SHORT).show()
            fetchGpsLocation()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchGpsLocation() {
        if (!hasLocationPermission()) return
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    lifecycleScope.launch {
                        prefsRepo.updateLocation(true, "বর্তমান অবস্থান", location.latitude, location.longitude)
                    }
                } else {
                    Toast.makeText(this, "অবস্থান পাওয়া যায়নি। ফোনের লোকেশন চালু আছে কি না দেখুন।", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "অবস্থান নির্ণয় ব্যর্থ হয়েছে", Toast.LENGTH_LONG).show()
            }
    }

    private fun previewAudio(mode: String, uriStr: String?) {
        stopPreview()
        val uri: Uri = when {
            mode == "custom_adhan" && !uriStr.isNullOrEmpty() -> Uri.parse(uriStr)
            mode == "default" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            mode == "custom_adhan" -> {
                Toast.makeText(this, "আগে একটি অডিও ফাইল বাছাই করুন", Toast.LENGTH_SHORT).show()
                return
            }
            else -> return // শুধু ভাইব্রেশন মোডে শোনার কিছু নেই
        }
        try {
            val mp = MediaPlayer()
            testMediaPlayer = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.setOnCompletionListener { stopPreview() }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            Toast.makeText(this, "অডিও চালানো যায়নি", Toast.LENGTH_SHORT).show()
            stopPreview()
        }
    }

    private fun stopPreview() {
        testMediaPlayer?.let {
            try {
                it.release()
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
        testMediaPlayer = null
    }

    override fun onStop() {
        super.onStop()
        stopPreview()
    }

    override fun onDestroy() {
        stopPreview()
        super.onDestroy()
    }
}

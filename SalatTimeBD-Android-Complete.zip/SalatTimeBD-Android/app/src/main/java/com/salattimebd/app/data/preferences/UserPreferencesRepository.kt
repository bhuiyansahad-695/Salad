package com.salattimebd.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// DataStore অবশ্যই প্রতি ফাইলে একটাই instance হতে হবে, তাই top-level delegate।
private val Context.userSettingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

class UserPreferencesRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.applicationContext.userSettingsDataStore

    private object Keys {
        val USE_GPS = booleanPreferencesKey("use_gps")
        val DISTRICT = stringPreferencesKey("selected_district")
        val LATITUDE = doublePreferencesKey("latitude")
        val LONGITUDE = doublePreferencesKey("longitude")
        val METHOD_ID = intPreferencesKey("calculation_method_id")
        val ASR_SCHOOL = intPreferencesKey("asr_school")
        val BENGALI_NUMERALS = booleanPreferencesKey("use_bengali_numerals")
        val LAST_SYNC_TS = longPreferencesKey("last_sync_timestamp")
        val LAST_SYNC_STATUS = stringPreferencesKey("last_sync_status")
    }

    val userSettingsFlow: Flow<UserSettings> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toUserSettings() }

    suspend fun updateAlarmConfig(prayerId: String, config: PrayerAlarmConfig) {
        dataStore.edit { p ->
            p[booleanPreferencesKey("alarm_${prayerId}_enabled")] = config.enabled
            p[intPreferencesKey("alarm_${prayerId}_minutes_before")] = config.minutesBefore
            p[stringPreferencesKey("alarm_${prayerId}_sound_mode")] = config.soundMode
            val uriKey = stringPreferencesKey("alarm_${prayerId}_audio_uri")
            val uri = config.customAudioUri
            if (uri.isNullOrEmpty()) p.remove(uriKey) else p[uriKey] = uri
        }
    }

    suspend fun updateLocation(useGps: Boolean, district: String, latitude: Double, longitude: Double) {
        dataStore.edit { p ->
            p[Keys.USE_GPS] = useGps
            p[Keys.DISTRICT] = district
            p[Keys.LATITUDE] = latitude
            p[Keys.LONGITUDE] = longitude
        }
    }

    suspend fun updateCalculationSettings(methodId: Int, asrSchool: Int) {
        dataStore.edit { p ->
            p[Keys.METHOD_ID] = methodId
            p[Keys.ASR_SCHOOL] = asrSchool
        }
    }

    suspend fun updateBengaliNumerals(useBengali: Boolean) {
        dataStore.edit { p -> p[Keys.BENGALI_NUMERALS] = useBengali }
    }

    suspend fun updateSyncStatus(timestamp: Long, status: String) {
        dataStore.edit { p ->
            p[Keys.LAST_SYNC_TS] = timestamp
            p[Keys.LAST_SYNC_STATUS] = status
        }
    }

    private fun Preferences.toUserSettings(): UserSettings {
        val d = UserSettings()
        return UserSettings(
            useGps = this[Keys.USE_GPS] ?: d.useGps,
            selectedDistrict = this[Keys.DISTRICT] ?: d.selectedDistrict,
            latitude = this[Keys.LATITUDE] ?: d.latitude,
            longitude = this[Keys.LONGITUDE] ?: d.longitude,
            calculationMethodId = this[Keys.METHOD_ID] ?: d.calculationMethodId,
            asrSchool = this[Keys.ASR_SCHOOL] ?: d.asrSchool,
            useBengaliNumerals = this[Keys.BENGALI_NUMERALS] ?: d.useBengaliNumerals,
            fajrAlarm = readAlarm("fajr"),
            dhuhrAlarm = readAlarm("dhuhr"),
            asrAlarm = readAlarm("asr"),
            maghribAlarm = readAlarm("maghrib"),
            ishaAlarm = readAlarm("isha"),
            lastSyncTimestamp = this[Keys.LAST_SYNC_TS] ?: d.lastSyncTimestamp,
            lastSyncStatus = this[Keys.LAST_SYNC_STATUS] ?: d.lastSyncStatus
        )
    }

    private fun Preferences.readAlarm(prayerId: String): PrayerAlarmConfig {
        val d = PrayerAlarmConfig()
        return PrayerAlarmConfig(
            enabled = this[booleanPreferencesKey("alarm_${prayerId}_enabled")] ?: d.enabled,
            minutesBefore = this[intPreferencesKey("alarm_${prayerId}_minutes_before")] ?: d.minutesBefore,
            soundMode = this[stringPreferencesKey("alarm_${prayerId}_sound_mode")] ?: d.soundMode,
            customAudioUri = this[stringPreferencesKey("alarm_${prayerId}_audio_uri")]
        )
    }
}

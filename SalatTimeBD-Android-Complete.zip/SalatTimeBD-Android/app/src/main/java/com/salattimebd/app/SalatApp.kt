package com.salattimebd.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.salattimebd.app.alarm.PrayerRescheduleWorker

class SalatApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        PrayerRescheduleWorker.ensurePeriodic(this)
    }

    private fun createNotificationChannels() {
        // minSdk 26, তাই NotificationChannel সবসময় ব্যবহারযোগ্য।
        val nm = getSystemService(NotificationManager::class.java) ?: return

        val start = NotificationChannel(
            CHANNEL_PRAYER_START,
            "ওয়াক্ত শুরুর বিজ্ঞপ্তি",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "নামাজের ওয়াক্ত শুরু হলে সতর্কবার্তা"
            enableVibration(false) // কম্পন Receiver নিজেই দেয়
        }

        val reminder = NotificationChannel(
            CHANNEL_PRAYER_REMINDER,
            "ওয়াক্ত শেষের আগে সতর্কতা",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "ওয়াক্ত শুরুর কিছু মিনিট আগে অগ্রিম সতর্কবার্তা"
            enableVibration(false)
        }

        val silent = NotificationChannel(
            CHANNEL_PRAYER_SILENT,
            "নীরব সতর্কতা (ভাইব্রেশন / নিজস্ব আজান)",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "শব্দ ছাড়া বিজ্ঞপ্তি; নিজস্ব আজান বা ভাইব্রেশন অ্যাপ নিজেই চালায়"
            setSound(null, null)
            enableVibration(false)
        }

        nm.createNotificationChannels(listOf(start, reminder, silent))
    }

    companion object {
        const val CHANNEL_PRAYER_START = "prayer_start"
        const val CHANNEL_PRAYER_REMINDER = "prayer_reminder"
        const val CHANNEL_PRAYER_SILENT = "prayer_silent"
    }
}

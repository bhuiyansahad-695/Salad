package com.salattimebd.app.util

import java.time.DayOfWeek
import java.time.LocalDate
import java.util.Locale

object BengaliUtils {

    private val BENGALI_DIGITS = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    private val GREGORIAN_MONTHS = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val HIJRI_MONTHS = listOf(
        "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল আউয়াল", "জমাদিউস সানি",
        "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
    )

    fun toBengaliDigits(value: Int): String = toBengaliDigits(value.toString())

    fun toBengaliDigits(value: Long): String = toBengaliDigits(value.toString())

    fun toBengaliDigits(text: String): String {
        val sb = StringBuilder(text.length)
        for (c in text) {
            if (c in '0'..'9') sb.append(BENGALI_DIGITS[c - '0']) else sb.append(c)
        }
        return sb.toString()
    }

    fun localizeDigits(text: String, useBengali: Boolean): String =
        if (useBengali) toBengaliDigits(text) else text

    /** "04:35" -> "৪:৩৫ এএম" (বাংলা অঙ্ক চালু থাকলে) অথবা "4:35 AM" */
    fun formatTime12h(time24: String, useBengali: Boolean = true): String {
        val parts = time24.trim().split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: return time24
        val m = parts.getOrNull(1)?.toIntOrNull() ?: return time24
        val h12 = if (h % 12 == 0) 12 else h % 12
        val numbers = String.format(Locale.US, "%d:%02d", h12, m)
        val period = if (h < 12) {
            if (useBengali) "এএম" else "AM"
        } else {
            if (useBengali) "পিএম" else "PM"
        }
        return "${localizeDigits(numbers, useBengali)} $period"
    }

    /** মিলিসেকেন্ড -> "HH:MM:SS" */
    fun formatCountdown(millis: Long, useBengali: Boolean = true): String {
        val totalSec = (millis.coerceAtLeast(0L)) / 1000L
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return localizeDigits(String.format(Locale.US, "%02d:%02d:%02d", h, m, s), useBengali)
    }

    fun weekdayName(day: DayOfWeek): String = when (day) {
        DayOfWeek.SATURDAY -> "শনিবার"
        DayOfWeek.SUNDAY -> "রবিবার"
        DayOfWeek.MONDAY -> "সোমবার"
        DayOfWeek.TUESDAY -> "মঙ্গলবার"
        DayOfWeek.WEDNESDAY -> "বুধবার"
        DayOfWeek.THURSDAY -> "বৃহস্পতিবার"
        DayOfWeek.FRIDAY -> "শুক্রবার"
    }

    /** "সোমবার, ৯ নভেম্বর ২০২৬" */
    fun gregorianLabel(date: LocalDate, useBengali: Boolean = true): String {
        val text = "${weekdayName(date.dayOfWeek)}, ${date.dayOfMonth} ${GREGORIAN_MONTHS[date.monthValue - 1]} ${date.year}"
        return localizeDigits(text, useBengali)
    }

    fun hijriMonthName(monthNumber: Int): String =
        HIJRI_MONTHS.getOrNull(monthNumber - 1) ?: ""
}

package com.salattimebd.app.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import com.salattimebd.app.MainActivity
import com.salattimebd.app.SalatApp
import com.salattimebd.app.util.BengaliUtils

class PrayerAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val prayerId = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER_ID) ?: return
        val prayerName = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER_NAME) ?: "নামাজ"
        val isReminder = intent.getBooleanExtra(PrayerAlarmScheduler.EXTRA_IS_REMINDER, false)
        val minutesBefore = intent.getIntExtra(PrayerAlarmScheduler.EXTRA_MINUTES_BEFORE, 0)
        val soundMode = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_SOUND_MODE) ?: "default"
        val audioUriString = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_AUDIO_URI)

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SalatTimeBD:Alarm")
        wakeLock.acquire(10_000L)

        try {
            val isCustomAudio = soundMode == "custom_adhan" && !audioUriString.isNullOrEmpty()
            // "default" মোড (অথবা অডিও ফাইল ছাড়া custom) হলে সিস্টেম সাউন্ডসহ চ্যানেল; অন্যথায় নীরব চ্যানেল
            val useSystemSound = soundMode == "default" || (soundMode == "custom_adhan" && !isCustomAudio)
            val channelId = when {
                !useSystemSound -> SalatApp.CHANNEL_PRAYER_SILENT
                isReminder -> SalatApp.CHANNEL_PRAYER_REMINDER
                else -> SalatApp.CHANNEL_PRAYER_START
            }

            val title = if (isReminder) {
                "$prayerName ওয়াক্তের আর ${BengaliUtils.toBengaliDigits(minutesBefore)} মিনিট বাকি"
            } else {
                "হাইয়্যা আলাস সালাহ! $prayerName ওয়াক্ত শুরু হয়েছে"
            }

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context, prayerId.hashCode(), openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText("সময়মত জামাতে নামাজ আদায়ের জন্য মসজিদে আসুন।")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            try {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
            } catch (e: Exception) {
                Log.w(TAG, "Vibration failed", e)
            }

            if (isCustomAudio) {
                playCustomAudio(context, audioUriString.orEmpty())
            }

            // প্রতিটি ওয়াক্তের জন্য আলাদা, স্থির notification id (শুরু: ১০০+, অগ্রিম: ২০০+)
            val index = PrayerAlarmScheduler.PRAYER_IDS.indexOf(prayerId).coerceAtLeast(0)
            val notificationId = (if (isReminder) 200 else 100) + index
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(notificationId, builder.build())

            // আগামী দিনের অ্যালার্ম নিশ্চিত করতে আবার সেট করা
            PrayerRescheduleWorker.enqueueNow(context)
        } finally {
            if (wakeLock.isHeld) wakeLock.release()
        }
    }

    private fun playCustomAudio(context: Context, uriString: String) {
        releasePlayer()
        var mp: MediaPlayer? = null
        try {
            mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(context, Uri.parse(uriString))
            mp.setOnCompletionListener { releasePlayer() }
            mp.setOnErrorListener { _, _, _ ->
                releasePlayer()
                true
            }
            mp.prepare()
            mp.start()
            activePlayer = mp // রেফারেন্স ধরে রাখা, নইলে GC প্লেব্যাক থামিয়ে দিতে পারে
        } catch (e: Exception) {
            // ফাইল মুছে গেলে বা অনুমতি হারালে ক্র্যাশ না করে নীরবে এগিয়ে যাওয়া
            Log.w(TAG, "Custom adhan playback failed", e)
            try {
                mp?.release()
            } catch (inner: Exception) {
                Log.w(TAG, "Release failed", inner)
            }
            activePlayer = null
        }
    }

    companion object {
        private const val TAG = "PrayerAlarmReceiver"

        @Volatile
        private var activePlayer: MediaPlayer? = null

        @Synchronized
        private fun releasePlayer() {
            val p = activePlayer
            activePlayer = null
            if (p != null) {
                try {
                    p.release()
                } catch (e: Exception) {
                    Log.w(TAG, "Release failed", e)
                }
            }
        }
    }
}

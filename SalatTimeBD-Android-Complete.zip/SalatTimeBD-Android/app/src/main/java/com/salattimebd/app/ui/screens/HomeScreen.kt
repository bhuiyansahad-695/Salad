package com.salattimebd.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.salattimebd.app.data.preferences.PrayerAlarmConfig
import com.salattimebd.app.data.preferences.UserSettings
import com.salattimebd.app.data.repository.DailyPrayerData
import com.salattimebd.app.data.repository.Resource
import com.salattimebd.app.util.BengaliUtils
import com.salattimebd.app.util.EndRuleType
import com.salattimebd.app.util.PrayerTimeUtils
import com.salattimebd.app.util.PrayerTiming
import kotlinx.coroutines.delay
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    prayerDataState: Resource<DailyPrayerData>,
    userSettings: UserSettings,
    onManualRefresh: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToDiagnostics: () -> Unit,
    onAlarmToggle: (String, Boolean) -> Unit,
    onSaveAlarmConfig: (String, PrayerAlarmConfig) -> Unit,
    onSelectAudio: (String) -> Unit,
    onPreviewAudio: (String, String?) -> Unit
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            nowMillis = System.currentTimeMillis()
        }
    }

    var editingPrayerId by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সালাত টাইম বিডি", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onManualRefresh) {
                        Icon(Icons.Filled.Refresh, contentDescription = "রিফ্রেশ")
                    }
                    IconButton(onClick = onNavigateToDiagnostics) {
                        Icon(Icons.Filled.BugReport, contentDescription = "ডায়াগনস্টিকস")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "সেটিংস")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (prayerDataState) {
                is Resource.Loading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                is Resource.Error -> {
                    ErrorContent(
                        message = prayerDataState.message,
                        onRetry = onManualRefresh,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                is Resource.Success -> {
                    PrayerContent(
                        data = prayerDataState.data,
                        userSettings = userSettings,
                        nowMillis = nowMillis,
                        onEditAlarm = { editingPrayerId = it },
                        onAlarmToggle = onAlarmToggle
                    )
                }
            }
        }
    }

    val editId = editingPrayerId
    if (editId != null) {
        val prayerName = if (prayerDataState is Resource.Success) {
            prayerDataState.data.timings.firstOrNull { it.id == editId }?.nameBn ?: "নামাজ"
        } else {
            "নামাজ"
        }
        AlarmConfigDialog(
            prayerName = prayerName,
            prayerId = editId,
            config = userSettings.alarmFor(editId),
            useBengali = userSettings.useBengaliNumerals,
            onDismiss = { editingPrayerId = null },
            onSave = { updated ->
                onSaveAlarmConfig(editId, updated)
                editingPrayerId = null
            },
            onSelectAudio = { onSelectAudio(editId) },
            onPreviewAudio = onPreviewAudio
        )
    }
}

@Composable
private fun ErrorContent(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.error
        )
        Button(onClick = onRetry) { Text("আবার চেষ্টা করুন") }
    }
}

@Composable
private fun PrayerContent(
    data: DailyPrayerData,
    userSettings: UserSettings,
    nowMillis: Long,
    onEditAlarm: (String) -> Unit,
    onAlarmToggle: (String, Boolean) -> Unit
) {
    val useBn = userSettings.useBengaliNumerals
    val status = PrayerTimeUtils.computeStatus(data.timings, data.dateIso, data.timezoneId, nowMillis)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { HeaderCard(data, useBn, status, nowMillis) }

        if (data.isOfflineFallback) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ইন্টারনেট সংযোগ নেই — সর্বশেষ সংরক্ষিত সময় দেখানো হচ্ছে।",
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        items(data.timings, key = { it.id }) { timing ->
            PrayerRow(
                timing = timing,
                config = userSettings.alarmFor(timing.id),
                isCurrent = status?.currentName == timing.nameBn,
                useBn = useBn,
                onEditAlarm = { onEditAlarm(timing.id) },
                onToggle = { enabled -> onAlarmToggle(timing.id, enabled) }
            )
        }
    }
}

@Composable
private fun HeaderCard(
    data: DailyPrayerData,
    useBn: Boolean,
    status: PrayerTimeUtils.WaqtStatus?,
    nowMillis: Long
) {
    val date = runCatching { LocalDate.parse(data.dateIso) }.getOrNull()

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocationOn, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(
                    text = data.locationName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            if (date != null) {
                Text(BengaliUtils.gregorianLabel(date, useBn), style = MaterialTheme.typography.bodyMedium)
            }
            if (data.hijriDateText.isNotEmpty()) {
                Text(
                    BengaliUtils.localizeDigits(data.hijriDateText, useBn),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (status != null) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                val currentName = status.currentName
                val currentEnd = status.currentEndMillis
                if (currentName != null && currentEnd != null) {
                    Text(
                        text = "চলমান: $currentName — শেষ হতে ${BengaliUtils.formatCountdown(currentEnd - nowMillis, useBn)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Text(
                    text = "পরবর্তী ওয়াক্ত: ${status.nextName}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = BengaliUtils.formatCountdown(status.nextStartMillis - nowMillis, useBn),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PrayerRow(
    timing: PrayerTiming,
    config: PrayerAlarmConfig,
    isCurrent: Boolean,
    useBn: Boolean,
    onEditAlarm: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val container = if (isCurrent) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = container),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .clickable { expanded = !expanded }
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = timing.nameBn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    val start = BengaliUtils.formatTime12h(timing.startTime, useBn)
                    val end = BengaliUtils.formatTime12h(timing.endTime, useBn)
                    Text(
                        text = "শুরু: $start  •  শেষ: $end",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (timing.isObligatory && config.enabled && config.minutesBefore > 0) {
                        val mins = BengaliUtils.localizeDigits(config.minutesBefore.toString(), useBn)
                        Text(
                            text = "অগ্রিম সতর্কতা: $mins মিনিট আগে",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                if (timing.isObligatory) {
                    IconButton(onClick = onEditAlarm) {
                        Icon(
                            imageVector = if (config.enabled) Icons.Filled.Notifications else Icons.Filled.NotificationsOff,
                            contentDescription = "অ্যালার্ম সেটিংস"
                        )
                    }
                    Switch(checked = config.enabled, onCheckedChange = onToggle)
                }
            }

            if (expanded) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(timing.fiqhRuleDescriptionBn, style = MaterialTheme.typography.bodySmall)
                if (timing.endRuleType == EndRuleType.CALCULATED_ESTIMATE) {
                    Text(
                        text = "এই ওয়াক্তের শেষ সময় আনুমানিক হিসাব।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

private val SOUND_MODES = listOf(
    "default" to "ডিফল্ট নোটিফিকেশন সাউন্ড",
    "vibrate" to "শুধু ভাইব্রেশন (শব্দ ছাড়া)",
    "custom_adhan" to "নিজের আজান অডিও"
)

private val MINUTES_BEFORE_OPTIONS = listOf(0, 5, 10, 15, 20, 30)

@Composable
private fun AlarmConfigDialog(
    prayerName: String,
    prayerId: String,
    config: PrayerAlarmConfig,
    useBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (PrayerAlarmConfig) -> Unit,
    onSelectAudio: () -> Unit,
    onPreviewAudio: (String, String?) -> Unit
) {
    var enabled by remember(prayerId) { mutableStateOf(config.enabled) }
    var minutesBefore by remember(prayerId) { mutableIntStateOf(config.minutesBefore) }
    var soundMode by remember(prayerId) { mutableStateOf(config.soundMode) }
    var lastUri by remember(prayerId) { mutableStateOf(config.customAudioUri) }

    // অডিও ফাইল নতুন করে বাছাই হলে মোড স্বয়ংক্রিয়ভাবে "নিজের আজান" হয়ে যায়
    LaunchedEffect(config.customAudioUri) {
        if (config.customAudioUri != lastUri) {
            lastUri = config.customAudioUri
            if (!config.customAudioUri.isNullOrEmpty()) soundMode = "custom_adhan"
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("$prayerName — অ্যালার্ম সেটিংস") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("অ্যালার্ম চালু", modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }

                Text("ওয়াক্তের কত মিনিট আগে সতর্ক করবে", style = MaterialTheme.typography.titleSmall)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MINUTES_BEFORE_OPTIONS.forEach { m ->
                        FilterChip(
                            selected = minutesBefore == m,
                            onClick = { minutesBefore = m },
                            label = {
                                Text(
                                    if (m == 0) "নেই"
                                    else BengaliUtils.localizeDigits(m.toString(), useBengali)
                                )
                            }
                        )
                    }
                }

                Text("শব্দের ধরন", style = MaterialTheme.typography.titleSmall)
                SOUND_MODES.forEach { (mode, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = soundMode == mode,
                                onClick = { soundMode = mode },
                                role = Role.RadioButton
                            )
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = soundMode == mode, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(label)
                    }
                }

                if (soundMode == "custom_adhan") {
                    val hasAudio = !config.customAudioUri.isNullOrEmpty()
                    Text(
                        text = if (hasAudio) "অডিও ফাইল বাছাই করা আছে" else "এখনো কোনো অডিও ফাইল বাছাই করা হয়নি",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(onClick = onSelectAudio) { Text("অডিও ফাইল বাছাই করুন") }
                }

                TextButton(onClick = { onPreviewAudio(soundMode, config.customAudioUri) }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("শুনে দেখুন")
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        PrayerAlarmConfig(
                            enabled = enabled,
                            minutesBefore = minutesBefore,
                            soundMode = soundMode,
                            customAudioUri = config.customAudioUri
                        )
                    )
                }
            ) { Text("সংরক্ষণ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
